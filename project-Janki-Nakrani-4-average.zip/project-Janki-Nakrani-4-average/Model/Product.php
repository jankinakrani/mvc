<?php


class Model_Product extends Model_Core_Table
{
	const STATUS_ACTIVE = 'yes';
	const STATUS_ACTIVE_LBL = 'Active';
	const STATUS_INACTIVE = 'no';
	const STATUS_INACTIVE_LBL = 'Inactive';
	const STATUS_DEFAULT = 2;

	public $tableName= 'product';
	public $primarykey= 'product_id';
}

?>