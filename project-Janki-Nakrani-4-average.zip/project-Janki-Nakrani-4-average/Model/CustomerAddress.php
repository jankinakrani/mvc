<?php
require_once 'Core/Table.php';

class Model_CustomerAddress extends Model_Core_Table
{
	public $tablename = "customer_address";
	public $primarykey = "address_id";
}
 
