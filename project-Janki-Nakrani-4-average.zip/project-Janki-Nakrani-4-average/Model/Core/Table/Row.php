<?php
require_once 'Model/Core/Table.php';
require_once 'Model/Core/Request.php';
/**
 * 
 */
class Model_Core_Table_Row 
{
	protected $data = [];
	protected $table = null;
	protected $tableclass = 'Model_Core_Table';

public function __construct($value='')
{
	// code...
}

	public function __set($key,$value){
		$this->data[$key] = $value;
	}

	public function __get($key){
		if(array_key_exists($key, $this->data))
		{
			return $this->data[$key];
		}
		return null;
	}

	public function __unset($key)
	{
		if (array_key_exists($key,$this->data)) {
			unset($this->data[$key]);
		}
		return $this;
	}

	
	public function getTableName()
	{
		return $this->getTable()->getTableName();
	}

	public function getPrimaryKey()
	{
		return $this->getTable()->getPrimaryKey();
	}

	public function setTable($table)
	{
		$this->table = $table;
		return $this;
	}

	public function getTable()
	{
		$tableclass = $this->tableclass;
		if ($this->table!=null) {
			return $this->table;
		}
		$model = new $tableclass();
		$this->setTable($model);
		return $model;
	}

	public function setData($data)
	{
		$this->data = $data;
		return $this;
	}

	public function getData($key=null)
	{
		if ($key == null) {
		return $this->data;
		}
		if(array_key_exists($key, $this->data))
		{
			return $this->data[$key];
		}
		return null;
	}

	public function addData($key,$value)
	{
		$this->data[$key] = $value;
		return $this;
	}
	public function removeData($key=null)
	{
		if ($key == null) {
			$this->data = [];
		}
		if (array_key_exists($key,$this->data)) {
			unset($this->data[$key]);
		}
		return $this;
	}

	public function save()
	{
		if (array_key_exists($this->getPrimaryKey(), $this->data) && $this->data[$this->getPrimaryKey()]) {
			$condition = [$this->getPrimaryKey()=>$this->data[$this->getPrimaryKey()]];
			$result = $this->getTable()->update($this->data,$condition);
			if ($result) {
				return $this->load($this->data[$this->getPrimaryKey()]);
			}
			return false;
		}else{

			$insertid = $this->getTable()->insert($this->data);
			if ($insertid) {
				return $this->load($insertid);
			}
			return false;
		}
	}

	public function fetchAll($query)
	{
		$result = $this->getTable()->fetchAll($query);
		if (!$result) {
			return false;
		}
		foreach ($result as &$row) {
			$row =  (new $this)->setData($row)->setTable($this->getTable());
		}
		return $result;
	}

	public function load($id,$column=null)
	{
		if (!$column) {
			$column = $this->getPrimaryKey();
		}
		 $query = "SELECT * FROM `{$this->getTableName()}` WHERE `{$column}` = '{$id}'";
		$result = $this->getTable()->fetchRow($query);
		if ($result) {
				$this->data = $result;
		}
		return $this;
	}

	public function fetchRow($query)
	{
		$result = $this->getTable()->fetchRow($query);
		if ($result) {
				$this->data = $result;
				return $this;
		}
		return false;

	}

	public function delete()
	{
		$id	 = $this->getData( $this->getPrimaryKey());
		if (!$id) {
			return false;
		}
		$this->getTable()->delete($id);
		return true;
	}

	
}
?>