<?php

require_once 'Model/Core/Table/Row.php';

/**
 * 
 */
class Model_CustomerAddress_Row extends Model_Core_Table_Row	
{
	
	public $tableclass = "Model_CustomerAddress";
}