<?php
// require_once 'Model/Core/Table/Row.php';

/**
 * 
 */
class Model_Admin_Row extends Model_Core_Table_Row
{
	
	public function __construct()
	{
		parent:: __construct();
		$this->setTableClass('model_Admin');
	}

	public function getStatus()
	{
		if ($this->status) {
			return $this->status;
		}
		return Model_Admin::STATUS_DEFAULT;
	}

	public function getStatusText($status)
	{
		$statuses = $this->getTable()->getStatusOptions();
		if (array_key_exists($this->status, $statuses)) 
		{
			return $statuses[$this->status];
		}
		
		return Model_Admin::STATUS_DEFAULT;
	}
	
}
?>