<?php
require 'Model/Core/Table.php';


/**
 * 
 */
class Model_Category extends Model_Core_Table
{
	
	public $tableName='category';
	public $primarykey='category_id';
}


?>