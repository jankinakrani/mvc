<?php
require_once 'Model/Core/Table.php';

/**
 * 
 */
class Model_Salesman extends Model_Core_Table
{
	
	public $tableName='salesman';
	public $primarykey='salesman_id';

}


?>