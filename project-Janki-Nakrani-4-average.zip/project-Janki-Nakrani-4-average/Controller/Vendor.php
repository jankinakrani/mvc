<?php

class Controller_Vendor extends Controller_Core_Action
{
	protected $vendor=null;
	protected $vendorid=null;
	protected $modelvendor=null;
	protected $modeladdress=null;

	public function setVendor($vendor)
	{
		$this->vendor = $vendor;
		return $this;
	}
	public function getVendor()
	{
		return $this->vendor;
	}
	public function setVendorid($vendorid)
	{
		$this->vendorid = $vendorid;
		return $this;
	}
	public function getVendorid()
	{
		return $this->vendorid;
	}
	public function setModelVendor($modelvendor)
	{
		$this->modelvendor = $modelvendor;
		return $this;
	}
	public function getModelVendor()
	{
		if ($this->modelvendor!=null)
		{
			return $this->modelvendor;
		}
		$modelvendor=new Model_Vendor();
		$this->setModelVendor($modelvendor);
		return $modelvendor;
	}
	public function setModelAddress($modeladdress)
	{
		$this->modeladdress = $modeladdress;
		return $this;
	}
	public function getModelAddress()
	{
		if ($this->modeladdress!=null)
		{
			return $this->modeladdress;
		}
		$modeladdress = new Model_Vendor_Address();
		print_r($modeladdress);
		$this->setModelAddress($modeladdress);
		return $this->modeladdress;
	}
	public function gridAction()
	{
		try {
			$vendorRow = Ccc::getModel('vendor_row');
		$vendor=$this->getModelVendor()->fetchAll();
		if (!$vendor) {
			throw new Exception("Data not Display", 1);
		}
		$this->getView()->setTemplate('vendor/grid.phtml')->setData(['vendors' => $vendor]);
		$this->render();
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage("Data Not Found",Model_Core_Message::FAILURE);
		$this->redirect("index.php?c=vendor&a=grid");
		}
	}
	public function addAction()
	{
		$vendorRow = Ccc::getModel('vendor_row');
		if (!$vendorRow) {
			throw new Exception("Vender not found", 1);
			
		}
		$this->getView()->setTemplate('vendor/edit.phtml')->setData(['vendor'=>$vendorRow]);
		$this->render();
	}
	public function insertAction()
	{
		try {
			
		$request=$this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$vendor = $request->getPost('vendor');
		if (!$vendor) {
			throw new Exception("Data Not Posted", 1);
		}
		$vid = $this->getModelVendor()->insert($vendor);
		if (!$vid) {
			throw new Exception("InsertId Not Found", 1);
		}
		$data=$this->getRequest()->getPost('vendor_address');
		$data['vendor_id']=$vid;
		if (!$data) {
			throw new Exception("Address Data Not Posted", 1);
		}
		$this->getModelAddress()->insert($data);
		$message = new Model_Core_Message();
		$message->addMessage("Data Inserted Successfully..",Model_Core_Message::SUCCESS);
		$this->redirect("index.php?c=vendor&a=grid");
		} catch (Exception $e) {
		$message = new Model_Core_Message();
		$message->addMessage("Data Not Inserted ..",Model_Core_Message::FAILURE);
		$this->redirect("index.php?c=vendor&a=grid");
		}
	}
	public function editAction()
	{
		try {
				$vendor = Ccc::getModel('Vendor_Row');
				$request=$this->getRequest();
				if (!$request) {
					throw new Exception("Invalid Request", 1);
				}
				$id = $request->getParam('vendor_id');
				if (!$id) {
					throw new Exception("Id not found", 1);
				}
				$row = $vendor->load($id,'vendor_id');
				if (!$row) {
						throw new Exception("Data not found", 1);
				}
				$this->getView()->setTemplate('vendor/edit.phtml')->setData(['vendor' =>$row]);
				$this->render();
		}
		catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage('data not found',Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=vendor&a=grid");
		}
	}

	public function saveAction()
		{
			try {
				$vendor = Ccc::getModel('Vendor_Row');
				$request=$this->getRequest();
					if (!$request){

				throw new Exception("Invalid Request", 1);
					}

					$vendors = $request->getPost('vendor');
					if (!$vendors) {
						throw new Exception("Data not posted", 1);
					}
					$id = $request->getParam('vendor_id');
					if(!$id){
						if(!$vendor->load($id)){
							throw new Exception("Data not found.", 1);
						}
					}
					$data = $vendor->setData($vendors);
					if ($data->vendor_id) {
						$data->update_at = date('Y-m-d h:i:sa');
					}
					else{
						$data->create_at = date('Y-m-d h:i:sa');
					}
					$data = $vendor->save();
					$message = new Model_Core_Message();
					$message->addMessage("Data saved successfully.",Model_Core_Message::SUCCESS);
				$this->redirect("index.php?c=vendor&a=grid");
				
			} catch (Exception $e) {
				$message = new Model_Core_Message();
				$message->addMessage("data not saved.",Model_Core_Message::FAILURE);
				$this->redirect("index.php?c=vendor&a=grid");
			}
		}

	public function updateAction()
	{
		try {
			
		$request=$this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$vendor=$request->getPost('vendor');
		$vendor['update_at'] = date("Y-m-d h:i:sa");
		if (!$vendor) {
			throw new Exception("Data Not Posted", 1);
		}
		$this->getModelVendor()->update($vendor,$vendor['vendor_id']);
		$message = new Model_Core_Message();
		$message->addMessage("Row updated Successfully..",Model_Core_Message::SUCCESS);
		$this->redirect("index.php?c=vendor&a=grid");
		} catch (Exception $e) {
		$message = new Model_Core_Message();
		$message->addMessage("Data Not updated ..",Model_Core_Message::FAILURE);
		$this->redirect("index.php?c=vendor&a=grid");
		}
	}
	public function deleteAction()
	{
		try {
			
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$id = $request->getParam('vendor_id');
		if (!$id) {
			throw new Exception("Invalid Id", 1);
		}
		$this->getModelVendor()->delete($id);
		$message = new Model_Core_Message();
		$message->addMessages("Row Delete Successfully..",Model_Core_Message::SUCCESS);
		$this->redirect("index.php?c=vendor&a=grid");
		} catch (Exception $e) {
		$message = new Model_Core_Message();
		$message->addMessage("Data Not Deletes ..",Model_Core_Message::FAILURE);
		$this->redirect("index.php?c=vendor&a=grid");
		}
	}
	
}
?>