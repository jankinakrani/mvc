<?php
require 'Model/Core/Table.php';

class Model_Shipping extends Model_Core_Table
{
	public $tableName='shippingmethod';
	public $primarykey='shipping_id';

}

?>