<?php
require_once 'Model/Core/Table.php';


/**
 * 
 */
class Model_Salesman_Address extends Model_Core_Table
{
	
	public $tableName='salesman_address';
	public $primarykey='address_id';

}



?>