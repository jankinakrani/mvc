<?php
require_once 'Model/Core/Table/Row.php';

class Model_Payment_Row extends Model_Core_Table_Row
{
	
	protected $tableClass = 'Model_payment';
	const STATUS_ACTIVE = 'yes';
	const STATUS_ACTIVE_LBL = 'Active';
	const STATUS_INACTIVE = 'no';
	const STATUS_INACTIVE_LBL = 'Inactive';

	public function getStatusOptions()
	{
		return [
			self::STATUS_ACTIVE=> self::STATUS_ACTIVE_LBL,
			self::STATUS_INACTIVE=> self::STATUS_INACTIVE_LBL
		];
	}
}
?>