<?php
require 'Model/Core/Table.php';

class Model_Payment extends Model_Core_Table
{
	public $tableName='payment';
	public $primarykey='payment_id';
}


?>