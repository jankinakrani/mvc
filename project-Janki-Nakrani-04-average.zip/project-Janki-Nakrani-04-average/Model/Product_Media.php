<?php
require_once 'Core/Table.php';

/**
 * 
 */
class Model_Product_Media extends Model_Core_Table
{
	public $tableName = "media";
	public $primarykey = "media_id";
	 
}
?>