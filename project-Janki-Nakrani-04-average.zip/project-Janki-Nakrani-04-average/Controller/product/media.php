<?php
require_once 'Controller/Core/Action.php';
require_once 'Model/Product_Media.php';
require_once 'Model/Core/Message.php';
// require_once 'Model/Product_Media/Row.php';
/**
 * 
 */
class Controller_Product_Media extends Controller_Core_Action
{
	
	protected $productMedia = null;
	protected $modelMedia = null;

	public function setProductMedia($productmedia)
	{
		$this->productmedia = $productmedia;
		return $this;
	}

	public function getProductMedia()
	{
		return $this->productmedia;
	}

	public function setModelMedia($modelMedia)
	{
		$this->modelMedia = $modelMedia;
		return $this;
	}

	public function getModelMedia()
	{
		if ($this->modelMedia!=null) {
			return $this->modelMedia;
		}
		$modelMedia = new Model_Product_Media();
		$this->setModelMedia($modelMedia);
		return $modelMedia;
	}

	public function gridAction()
	{
		$media = $this->getModelMedia()->fetchAll();
		$this->setProductMedia($media);
		$this->getTemplate('product_media/grid.phtml');
	}

	public function addAction()
	{
		$this->getTemplate('product_media/add.phtml');
	}

	public function insertAction()
	{
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
			
		}
		echo "<pre>";
		$productid = $request->getParam('product_id');
		$image = $_FILES['image'];
		$imagename = $image['name'];
		$filename = $request->getPost('name');

		$image1['image'] = $imagename;
		$image1['name'] = $filename;

		$id = $this->getModelMedia()->insert($image1);

		$filetemp=$image['tmp_name'];
		$fileseprate=explode('.', $imagename);
		$fileextension=$fileseprate[1];
		$name=$id.'.'.$fileextension;
		$uploadimage='View/product_media/image/'.$name;
		$imagename=[];
		$imagename['image'] = $name;
		// print_r($imagename);
     	move_uploaded_file( $_FILES['image']['tmp_name'], $uploadimage);
     	$this->getModelMedia()->update($imagename,$id);

     	return $this->redirect("index.php?c=product_media&a=grid&product_id=$productid");

	}

	public function updateAction()
	{echo "<pre>";
		try {
			    $request= $this->getRequest();
			    if (!$request) {
			    	throw new Exception("Invalid Request", 1);
			    }
			    $productid = $request->getParam('product_id');
			     // print_r($productid);
			    $base = $request->getPost('base');
			    $small = $request->getPost('small');
			    $thumb = $request->getPost('thumbnail');
    			$gallery = $request->getPost('gallery');
			    
			    $data = ['base'=>0,'small'=>0,'thumb'=>0,'gallery'=>0];
			    $condition = ['product_id'=>$productid];
			    $images = $request->getPost();
			    print_r($images);
			    $result = $this->getModelMedia()->update($data,$condition);
			    
			    	if (array_key_exists('base',$images)) {
			    		$data = ['base'=>1];
			    		// print_r($data);
			    		$result = $this->getModelMedia()->update($data,$images['base']);
					}

			    	$data = ['small'=>1];
			    	$result = $this->getModelMedia()->update($data,$small);

			    	$data = ['thumb'=>1];
			    	$result = $this->getModelMedia()->update($data,$thumb);

			    	$data = ['gallery'=>1];

			    	foreach ($gallery as $key => $value) {
			    		$result = $this->getModelMedia()->update($data,$value);
			    	}

	// return $this->redirect("index.php?a=grid&c=product_media&product_id=$productid");
	} catch (Exception $e) {
			// $mesaage = new Model_Core_Message();
			// $mesaage->addMessage("Image not Found..", Model_Core_Message::FAILURE);
	// return $this->redirect("index.php?a=grid&c=product_media&product_id=$productid");

		}
}

}	

?>