<?php
// require_once 'Controller/Core/Action.php';
// require_once 'Model/Product.php';
// require_once 'Model/Core/url.php';
// require_once 'Model/Core/Message.php';
// require_once 'Model/Product/Row.php';

class Controller_Product extends Controller_Core_Action
{

	protected $products= [];
	protected $productId= null;
	protected $productModel= null;
	protected $productRow = null;

	public function setProducts($product)
	{
  	   $this->products= $product;
  	   return $this;
	}

    public function getProducts()
	{
	  return $this->products;	  
	}

   public function setProductId($productId)
   {
   	$this->productId= $productId;
   	return $this;
   }

   public function getProductId($value="")
   {
   	return $this->productId;
   }

   public function setProductRow($productRow)
   {
   	$this->productRow = $productRow;
   	return $this;
   }

   public function getProductRow()
   {
   	if($this->productRow!=null){
   		return $this->productRow;
   	}
   	$productRow = new Model_Product_Row();
   	$this->setProductRow($productRow);

   	return $productRow;
   }

   public function setProductModel($productModel)
   {

   	$this->productModel= $productModel;
   	return $this;
   }

	public function getProductModel()
	{
		if ($this->productModel != null) 
		{
			return $this->productModel;
		}
		$productModel= new Model_Product();
		$this->setProductModel($productModel);
		return $productModel;
	}

	public function gridAction()
		{	
		try 
		{

			$product = Ccc::getModel('Product_Row');
			$sql="SELECT * FROM `product`";
			$products = $product->fetchAll($sql);

			if (!$products) {
				throw new Exception("Data not found", 1);
			}

			$this->getView()->setTemplate("product/grid.phtml")->setData(['products'=>$products]);
			$this->render();
			} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage('Data not Posted',Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=product&a=grid");
		}
	}

	public function addAction()
	{
		
		$product = Ccc::getModel('Product_Row');
			if (!$product) {
				throw new Exception("Product not found", 1);
			}
			$this->getView()->setTemplate('Product/edit.phtml')->setData(['products'=>$product])->render();
	}

	public function editAction()
	{	
	try {
		$product = Ccc::getModel('Product_Row');
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}

		$id = $request->getParam('product_id');
		print_r($id);
		if (!$id) {
			throw new Exception("row not found", 1);
		}

		$row = $product->load($id, 'product_id');
			if (!$row) {
				throw new Exception("No data found.", 1);
			}

		$this->getView()->setTemplate('Product/edit.phtml')->setData(['products'=>$row])->render();
		} catch (Exception $e) 

		{
			$message = new Model_Core_Message();
			$message->addMessage("Data not found",Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=product&a=grid");
		}	
	}

	public function saveAction()
	{
		try{
			$product = Ccc::getModel('Product_Row');
			$request = $this->getRequest();
			if (!$request->isPost()) {
				throw new Exception("Invalid request", 1);
			}

			$products = $request->getPost('product');
			if (!$products) {
				throw new Exception("Data not found", 1);
			}
			$id = $request->getParam('product_id');
			if (!$id) {
				if (!$product->load($id)) {
				throw new Exception("Id not valid", 1);
				}
			}
			$data = $product->setData($products);
			
			if(!$data->product_id){
				$data->create_at = date('Y-m-d h:i:sa');
			}
			else{
				$data->update_at = date('Y-m-d h:i:sa');
			}

			$message= new Model_Core_Message();
	 		$message->addMessage('Inserted successfully.',Model_Core_Message::SUCCESS);
	 		$this->redirect("index.php?c=product&a=grid");

		} catch (Exception $e){
			$message = new Model_Core_Message();
			$message->addMessage('Data not has been posted',Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=product&a=grid");
		}
	}

	public function deleteAction()
	{
		try {
		$product = Ccc::getModel('Product_Row');
		$request= $this->getRequest();
		if (!$request->isGet()) {
			throw new Exception("Invalid Request", 1);
		}

		$id = $request->getParam('product_id');
		if (!$id) {
			throw new Exception("Row not found", 1);
		}
		$product->load($id);
		$product->delete();

		$message= new Model_Core_Message();
		$message->addMessage('Product deleted successfully.', Model_Core_Message::SUCCESS);
		$this->redirect("index.php?c=product&a=grid");
		} catch (Exception $e) 

		{
		$message= new Model_Core_Message();
		$message->addMessage('Product not deleted.', Model_Core_Message::FAILURE);
		$this->redirect("index.php?c=product&a=grid");
		}
	}
}
?>	